# Meme Radar — mobile PWA

Run the backend on a cloud host or your computer:
1. Install Node.js 18+.
2. `npm install`
3. Set `X_BEARER_TOKEN` to your X API Bearer Token.
4. `npm start`
5. Open the resulting HTTPS URL in Safari and use Share → Add to Home Screen.

The UI is mobile-first and polls X every 30 seconds. For the fastest possible detection, replace polling with X Filtered Stream on the server.

Important: X documents that post view counts can be delayed by up to a minute and that not every post type has a view count. The app therefore displays a view value only when the API supplies an impression/view field; it does not invent missing views.
