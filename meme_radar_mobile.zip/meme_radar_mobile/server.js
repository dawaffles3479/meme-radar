const express = require("express");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 3000;
const TOKEN = process.env.X_BEARER_TOKEN;
app.use(express.static(path.join(__dirname, "public")));

const tickerRe = /\$[A-Za-z][A-Za-z0-9_]{1,14}\b/g;
function tickers(text){return [...new Set((text.match(tickerRe)||[]).map(x=>x.toUpperCase()))]}

app.get("/api/search", async (req,res)=>{
  if(!TOKEN) return res.status(500).json({error:"X_BEARER_TOKEN is not configured"});
  const q=(req.query.q||"$PEPE OR $DOGE OR $SHIB OR $BONK OR $WIF").slice(0,480);
  const p=new URLSearchParams({
    query:`(${q}) -is:retweet`,
    max_results:"100",
    "tweet.fields":"created_at,public_metrics,author_id",
    expansions:"author_id",
    "user.fields":"username"
  });
  try{
    const r=await fetch("https://api.x.com/2/tweets/search/recent?"+p,{headers:{Authorization:`Bearer ${TOKEN}`}});
    const j=await r.json(); if(!r.ok)return res.status(r.status).json(j);
    const users=Object.fromEntries((j.includes?.users||[]).map(u=>[u.id,u.username]));
    const posts=(j.data||[]).map(t=>({
      id:t.id,text:t.text,created_at:t.created_at,author:users[t.author_id]||"unknown",
      metrics:t.public_metrics||{},tickers:tickers(t.text)
    }));
    res.json({posts});
  }catch(e){res.status(502).json({error:e.message})}
});
app.listen(PORT,()=>console.log(`Meme Radar running on http://localhost:${PORT}`));
